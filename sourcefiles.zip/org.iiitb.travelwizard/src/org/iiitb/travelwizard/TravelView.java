package org.iiitb.travelwizard;

import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;


public class TravelView extends ViewPart {
	
   Button openWizard;
	public TravelView() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createPartControl(Composite parent) {
		
		final Composite lparent=parent;
		// TODO Auto-generated method stub
		lparent.setLayout(new GridLayout());
		openWizard=new Button(lparent,SWT.NONE);
		openWizard.setText("Open Travel Planner");
		openWizard.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e)
			{
				super.widgetSelected(e);
				
				   WizardDialog wizardDialog = new WizardDialog(lparent.getShell(),new TravelWizard());
						 wizardDialog.open();
			}
		});
		

		
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

}
