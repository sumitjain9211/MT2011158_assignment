package org.iiitb.travelwizard;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ComboViewer;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;

public class PageThree extends WizardPage {

	 private Composite container;
	 private TravelAgentModel agent;
	 private TravelDetails details;
	 private  ComboViewer viewer;
	 private DateTime date;
	 
	protected PageThree(TravelAgentModel agent,TravelDetails details) {
		super("last step");
		// TODO Auto-generated constructor stub
		setTitle("last step");
	    setDescription("Select Agent and Date of Journey");
	    this.agent=agent;
	    this.details=details;
	}

	@Override
	public void createControl(Composite parent) {
		// TODO Auto-generated method stub
		  container = new Composite(parent, SWT.NULL);
		  container.setLayout(new GridLayout(2,false));
		  setPageComplete(false);
		  Label travelAgent=new Label(container,SWT.NONE);
		  travelAgent.setText("Travel Agent");
		  viewer=new ComboViewer(container,SWT.NONE);
		   viewer.setContentProvider(new ArrayContentProvider());
		  
		    viewer.setInput(agent.getAgents());
			
			
			
			viewer.setLabelProvider(new LabelProvider()
			{
				 public String getText(Object element) {
					    TravelAgent p = (TravelAgent) element;
					    return p.getAgentName();
					  }
			}
					);
			
			
			viewer.addSelectionChangedListener(new ISelectionChangedListener() {
				
				@Override
				public void selectionChanged(SelectionChangedEvent event) {
					
				 int index=viewer.getCombo().getSelectionIndex();
				 String agent=viewer.getCombo().getItem(index);
				 String doj=date.getDay()+"-"+date.getMonth()+"-"+date.getYear();
				 if(!doj.isEmpty() && !agent.isEmpty())
				 {details.setAgentName(agent);
				 details.setDoj(doj);
				 setPageComplete(true);
				 }	
				 else
				 {
					 details.setAgentName("");
					 details.setDoj(""); 
				 }
				}
			});
			
			setControl(container);
			Label label=new Label(container,SWT.NONE);
			label.setText("date of journey");
			 date=new DateTime(container, SWT.CALENDAR);
		     date.addSelectionListener(new SelectionAdapter() {
		    	 public void widgetSelected(SelectionEvent e)
		    	 {
		    		 int index=viewer.getCombo().getSelectionIndex();
					 String agent=viewer.getCombo().getItem(index);
					 String doj=date.getDay()+"-"+date.getMonth()+"-"+date.getYear();
					 if(!doj.isEmpty() && !agent.isEmpty())
					 {details.setAgentName(agent);
					 details.setDoj(doj);
					 setPageComplete(true);
					 }
					 else
					 {
						 details.setAgentName("");
						 details.setDoj(""); 
					 }
					 
		    		 
		    	 }
			});
		     
	}

	

}
