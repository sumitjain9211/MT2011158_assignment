package org.iiitb.travelwizard;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;


public class PageOne extends WizardPage implements Listener{

	  private Text tourNameText;
	  private Composite container;
	  private TravelAgentModel agent;
	  private TravelDetails details;


	  public PageOne(TravelAgentModel agent,TravelDetails details) {
	      super("Step One");
	      setTitle("Step One");
	      setDescription("Welcome to Travel Planner !!");
	      this.agent=agent;
	      this.details=details;
	  }

	  public Text getTourTextBox()
	  {
		  return tourNameText;
		  
	  }
	  @Override
	  public void createControl(Composite parent) {
	    container = new Composite(parent, SWT.NULL);
	    container.setLayout(new GridLayout(2,false));
	    Label tourNameLabel= new Label(container, SWT.NONE);
	    tourNameLabel.setText("Enter Tour Name");
	    tourNameText = new Text(container, SWT.BORDER | SWT.SINGLE);
	    tourNameText.setText("");
	    GridData gd = new GridData(GridData.FILL_HORIZONTAL);
	    tourNameText.setLayoutData(gd);
	    setControl(container);
	    tourNameText.addListener(SWT.KeyUp, this);
	  
        setPageComplete(false);
	  }

	  
	
	  
		private  boolean isTextNonEmpty(Text t)
		{
			String s = t.getText();
			if ((s!=null) && (s.trim().length() >0)) return true;
			return false;
		}	
	

	@Override
	public void handleEvent(Event event) {
		// TODO Auto-generated method stub
	
	     
		setPageComplete(isTextNonEmpty(tourNameText));
		details.setTourName(tourNameText.getText());
	}

	
	
	
	
	
	/*
	 * Sets the completed field on the wizard class when all the information 
	 * is entered and the wizard can be completed
	 */	 

	
}
