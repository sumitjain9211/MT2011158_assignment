package org.iiitb.travelwizard;

public class TravelDetails {
	
private String agentName;
private String tourName;
private String source;
private String dest;
private String via;
private String doj;
public String getAgentName() {
	return agentName;
}
public void setAgentName(String agentName) {
	this.agentName = agentName;
}
public String getTourName() {
	return tourName;
}
public void setTourName(String tourName) {
	this.tourName = tourName;
}
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getDest() {
	return dest;
}
public void setDest(String dest) {
	this.dest = dest;
}
public String getVia() {
	return via;
}
public void setVia(String via) {
	this.via = via;
}
public String getDoj() {
	return doj;
}
public void setDoj(String doj) {
	this.doj = doj;
}
	
}
