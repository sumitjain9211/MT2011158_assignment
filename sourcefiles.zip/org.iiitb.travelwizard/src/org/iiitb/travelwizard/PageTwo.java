package org.iiitb.travelwizard;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;

public class PageTwo extends WizardPage implements Listener{
	
	
	private Text fromText;
	private Text toText;
	private Text viaText1;
	private Text viaText2;
	private Text viaText3;
	  private Composite container;
	  private TravelAgentModel agent;
	  private TravelDetails details;

	  public PageTwo(TravelAgentModel agent,TravelDetails details) {
	      super("Step Two");
	      setTitle("Step Two");
	    setDescription("Please provide details !!");
	      this.agent=agent;
	      this.details=details;
	  }

	  @Override
	  public void createControl(Composite parent) {
	    container = new Composite(parent, SWT.NULL);
	    container.setLayout(new GridLayout(2,false));
	    GridData gd = new GridData(GridData.FILL_HORIZONTAL);
	    
	    Label fromLabel= new Label(container, SWT.NONE);
	    fromLabel.setText("FROM");
	    fromText = new Text(container, SWT.BORDER | SWT.SINGLE);
	    fromText.setText("");
	    fromText.setLayoutData(gd);
	    fromText.addListener(SWT.KeyUp, this);
	  
	    Label toLabel= new Label(container, SWT.NONE);
	    toLabel.setText("TO");
	    toText = new Text(container, SWT.BORDER | SWT.SINGLE);
	    toText.setText("");
	    toText.setLayoutData(gd);
	    toText.addListener(SWT.KeyUp, this);
	   
	    Label viaLabel= new Label(container, SWT.NONE);
	    viaLabel.setText("via");
	    viaText1 = new Text(container, SWT.BORDER | SWT.SINGLE);
	    viaText1.setText("");
	    viaText1.setLayoutData(gd);
	    viaText1.addListener(SWT.KeyUp, this);
	    
	    Label empty1= new Label(container, SWT.NONE);
	    empty1.setText("");
	    viaText2= new Text(container, SWT.BORDER | SWT.SINGLE);
	    viaText2.setText("");
	    viaText2.setLayoutData(gd);
	    viaText2.addListener(SWT.KeyUp, this);
	    
	    Label empty2= new Label(container, SWT.NONE);
	    empty2.setText("");
	    viaText3 = new Text(container, SWT.BORDER | SWT.SINGLE);
	    viaText3.setText("");
	    viaText3.setLayoutData(gd);
	    viaText3.addListener(SWT.KeyUp, this);
	 
	 
	  
	   
	    // Required to avoid an error in the system
	    setControl(container);
	   
	    setPageComplete(false);
        
	  }

	  
	  private  boolean isTextNonEmpty(Text t)
		{
			String s = t.getText();
			if ((s!=null) && (s.trim().length() >0)) return true;
			return false;
		}	
		

	  @Override
	public void handleEvent(Event event) {
		// TODO Auto-generated method stub
		
	  //  setPageComplete(true);
		//getWizard().getContainer().updateButtons();	
		  if(isTextNonEmpty(fromText) && isTextNonEmpty(toText))
		  { setPageComplete(true);
	        details.setSource(fromText.getText()) ;
	        details.setDest(toText.getText());
	        details.setVia(viaText1.getText()+","+viaText2.getText()+","+viaText3.getText());
		  }
		  else
			  setPageComplete(false);
		  }
	  
	 
	
}
