package org.iiitb.travelwizard;

public class TravelAgent {
	
	private int tourId;
	private String agentName;
	
	

	public TravelAgent(int tourId, String agentName) {
		this.tourId = tourId;
		this.agentName = agentName;
	}
	public int getTourId() {
		return tourId;
	}
	public void setTourId(int tourId) {
		this.tourId = tourId;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	
}
