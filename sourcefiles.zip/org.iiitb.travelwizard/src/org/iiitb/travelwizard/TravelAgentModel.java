package org.iiitb.travelwizard;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;





public class TravelAgentModel {
	
	List<TravelAgent>  list;
	
	public TravelAgentModel()
	{
		
		list=new ArrayList<TravelAgent>();
	    fillList();
	}
	
	private void fillList() {
		// TODO Auto-generated method stub
		
		DataBase database=new DataBase();
		ResultSet rs=null;
		 database.setConnection();
		 String query="select * from travelagent";
		 try
		 {
		
		 database.statement=database.connection.createStatement();
		 rs=database.statement.executeQuery(query);
		 while(rs.next())
		 {
			 
			 int agentId=rs.getInt("agentId");
			 String agentName=rs.getString("agentName");
			 list.add(new TravelAgent(agentId, agentName))	;
			 }
		 
		 }catch(SQLException e)
		 {
			 
			 e.printStackTrace();
		 }
		 finally
		 {
			 
			try {
				database.statement.close();
				database.connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		 }
		
	}

	public List<TravelAgent> getAgents() {
	      
		return list;
	    }

}
