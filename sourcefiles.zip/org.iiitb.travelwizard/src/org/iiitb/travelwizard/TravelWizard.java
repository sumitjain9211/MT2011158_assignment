package org.iiitb.travelwizard;
import java.sql.SQLException;

import org.eclipse.jface.wizard.Wizard;

public class TravelWizard  extends Wizard{
	 protected PageOne one;
	 protected PageTwo two;
	protected PageThree three;
	 private TravelAgentModel agent;
	 private TravelDetails details;
    
	  public TravelWizard() {
	    super();
	  agent=new TravelAgentModel();
	 details=new TravelDetails();
	   setNeedsProgressMonitor(true);
	  }

	  @Override
	  public void addPages() {
	    one = new PageOne(agent,details);
	    two = new PageTwo(agent,details);
	   three = new PageThree(agent,details);
	    addPage(one);
	    addPage(two);
	    addPage(three);
	  }

	

	  @Override
	  public boolean performFinish() {
	   
		 DataBase database=new DataBase();
		 database.setConnection();
		 String query="insert into traveldata values('"+details.getTourName()+"','"+details.getSource()+"','"+details.getDest()+"','"+details.getVia()+"','"+details.getAgentName()+"','"+details.getDoj()+"')";
		 try
		 {
		
		 database.statement=database.connection.createStatement();
		 database.statement.executeUpdate(query);
		 }catch(SQLException e)
		 {
			 
			 e.printStackTrace();
		 }
		 finally
		 {
			 
			try {
				database.statement.close();
				database.connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		 }
		 
		 
		 
        System.out.println(details.getAgentName()+","+details.getSource()+","+details.getTourName()+","+details.getDest()+","+details.getDoj()+","+details.getVia());
	    return true;
	  }


} 
	


